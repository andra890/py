# 🚀 Telegram Userbot Auto Broadcast

## ⚙️ Deploy ke Heroku
1. Fork repo ini ke akun GitHub kamu.
2. Login ke [Heroku](https://dashboard.heroku.com/).
3. Buat app baru → hubungkan ke repo GitHub ini.
4. Pergi ke **Settings > Config Vars** lalu isi:
   - API_ID
   - API_HASH
   - SESSION_STRING
   - OWNER_ID
5. Pergi ke **Deploy > Manual Deploy > Deploy Branch**.
6. Setelah sukses, buka **Resources > Worker** → aktifkan dyno.

## 📝 Command
- `.sg` → simpan grup (reply pesan di grup).
- `.lg` → list grup.
- `.hp` → hapus grup.
- `.sb <delay_pesan> <delay_group> <durasi>` → broadcast copy.
- `.fw <delay_pesan> <delay_group> <durasi>` → broadcast forward.
- `.stop` → hentikan broadcast.
- `.menu` → tampilkan menu.

## 🔔 Catatan
- Saat userbot aktif, otomatis kirim pesan ke Saved Messages.
- Jika userbot mati tiba-tiba, akan kirim:  
  ```
  😴 Bntar ya, set ulang lagi...
  ```
  dan auto join ke channel `@palingg`.
